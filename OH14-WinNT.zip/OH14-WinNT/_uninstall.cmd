@setlocal EnableExtensions DisableDelayedExpansion
@echo off

set _leg=0
ver|findstr /C:" 5." >nul && set _leg=1
set winmaj=6&set winmin=0&set winbld=6000
for /f "tokens=2 delims=[]" %%G in ('ver') do for /f "tokens=2,3,4 delims=. " %%H in ("%%~G") do set "winmaj=%%H"&set "winmin=%%I"&set "winbld=%%J"
if %winmaj% lss 6 set _leg=1
if %winbld% lss 6000 set _leg=1
set _wxp=0
if %winbld% equ 2600 set _wxp=1
set _sk=2
if %_wxp% equ 1 set _sk=4

if %_leg% equ 0 whoami /groups | findstr /i /c:"S-1-16-16384" /c:"S-1-16-12288" >nul || (
echo ==== Notice ====
echo This script requires administrator privileges.
goto :end
)

set arch=64
if /i "%PROCESSOR_ARCHITECTURE%"=="x86" if "%PROCESSOR_ARCHITEW6432%"=="" set arch=32

set off_wow=
set off_path=
call :get_reg HKLM\SOFTWARE\Microsoft\Office\14.0\Common\InstallRoot off_path
if not defined off_path if %arch%==64 call :get_reg HKLM\SOFTWARE\Wow6432Node\Microsoft\Office\14.0\Common\InstallRoot off_wow

set osp_wow=
set osp_path=
call :get_reg HKLM\SOFTWARE\Microsoft\OfficeSoftwareProtectionPlatform osp_path
if defined off_wow call :get_reg HKLM\SOFTWARE\Wow6432Node\Microsoft\OfficeSoftwareProtectionPlatform osp_wow

if not defined osp_path if exist "%CommonProgramFiles%\Microsoft Shared\OfficeSoftwareProtectionPlatform\OSPPC.DLL" (
set "osp_path=%CommonProgramFiles%\Microsoft Shared\OfficeSoftwareProtectionPlatform\"
)
if not defined osp_path (
echo ==== Notice ====
echo osppc.dll not detected as installed
goto :end
)

set "osp_path=%osp_path:~0,-1%"
if defined osp_wow set "osp_wow=%osp_wow:~0,-1%"

net stop osppsvc /y 1>nul 2>nul
set _png=
call :closeOFF 1>nul 2>nul
if defined _png (
echo Closing Office programs...
ping 127.0.0.1 -n 6 1>nul 2>nul
)

if not defined off_path set "off_path=%osp_path%"
if not defined off_wow set "off_wow=%osp_wow%"
set unhook=
call :dehook osp_path "%osp_path%" "%off_path%" 1>nul 2>nul
call :dehook osp_wow "%osp_wow%" "%off_wow%" 1>nul 2>nul

if not defined unhook (
echo ==== Notice ====
echo ohook sppcs.dll not detected as installed
goto :end
)

echo Finished.
goto :end

:get_reg
for /f "skip=%_sk% tokens=1,2*" %%i in ('"reg.exe query %1 /v Path" 2^>nul') do if /i "%%i"=="Path" if not "%%~k"=="" if exist "%%~k\OSPP*" (
set "%2=%%~k"
)
goto :eof

:dehook
set _p_=
if defined %1 if exist "%~2\SPPCS.DLL" if exist "%~2\OSPPC.DLL" set "_p_=%~2"
if not defined _p_ goto :eof
del /f /q "%_p_%\OSPPC.DLL" || (set "msg=delete ohook sppc"&goto :abort)
copy /y "%_p_%\SPPCS.DLL" "%_p_%\OSPPC.DLL" || (set "msg=restore osppc"&goto :abort)
del /f /q "%_p_%\SPPCS.DLL" || (set "msg=delete backup osppc"&goto :abort)
if exist "%~3\SPPCS.DLL" del /f /q "%~3\SPPCS.DLL"
set unhook=1
goto :eof

:abort
echo ==== Error =====
echo Failed to %msg% dll file.
echo Close Office programs or restart the system and try again.
goto :end

:closeOFF
if not exist "%SystemRoot%\System32\tasklist.exe" goto :eof
if not exist "%SystemRoot%\System32\taskkill.exe" goto :eof
for %%# in (
msosync
msaccess
excel
groove
lync
onenote
outlook
powerpnt
mspub
winword
winproj
visio
msouc
ois
graph
) do (
tasklist /FI "IMAGENAME eq %%#.exe" | find /i "%%#.exe" && (
  taskkill /t /f /IM %%#.exe
  set _png=1
  )
)
goto :eof

:end
echo.
echo Press any key to exit.
pause >nul
exit
