@setlocal EnableExtensions DisableDelayedExpansion
@echo off

if not exist "%~dp0sppc*.dll" (
echo ==== Error =====
echo ohook sppc dll files not detected
goto :end
)

set _leg=0
ver|findstr /C:" 5." >nul && set _leg=1
set winmaj=6&set winmin=0&set winbld=6000
for /f "tokens=2 delims=[]" %%G in ('ver') do for /f "tokens=2,3,4 delims=. " %%H in ("%%~G") do set "winmaj=%%H"&set "winmin=%%I"&set "winbld=%%J"
if %winmaj% lss 6 set _leg=1
if %winbld% lss 6000 set _leg=1
set _wxp=0
if %winbld% equ 2600 set _wxp=1
set _sk=2
if %_wxp% equ 1 set _sk=4

if %_leg% equ 0 whoami /groups | findstr /i /c:"S-1-16-16384" /c:"S-1-16-12288" >nul || (
echo ==== Notice ====
echo This script requires administrator privileges.
goto :end
)

set arch=64
if /i "%PROCESSOR_ARCHITECTURE%"=="x86" if "%PROCESSOR_ARCHITEW6432%"=="" set arch=32

set off_wow=
set off_path=
call :get_reg HKLM\SOFTWARE\Microsoft\Office\14.0\Common\InstallRoot off_path
if not defined off_path if %arch%==64 call :get_reg HKLM\SOFTWARE\Wow6432Node\Microsoft\Office\14.0\Common\InstallRoot off_wow

if not defined off_path if not defined off_wow (
echo ==== Notice ====
echo Office 2010 MSI path not detected
goto :end
)

set osp_wow=
set osp_path=
call :get_reg HKLM\SOFTWARE\Microsoft\OfficeSoftwareProtectionPlatform osp_path
if defined off_wow call :get_reg HKLM\SOFTWARE\Wow6432Node\Microsoft\OfficeSoftwareProtectionPlatform osp_wow

set _err=
if not defined osp_path set _err=1
if defined osp_path if not exist "%osp_path%\OSPPC.DLL" set _err=1
if defined off_wow if not exist "%osp_wow%\OSPPC.DLL" set _err=1
if defined _err (
echo ==== Notice ====
echo osppc.dll path not detected as installed
goto :end
)

set "osp_path=%osp_path:~0,-1%"
if defined osp_wow set "osp_wow=%osp_wow:~0,-1%"

net stop osppsvc /y 1>nul 2>nul
set _png=
call :closeOFF 1>nul 2>nul
if defined _png (
echo Closing Office programs...
ping 127.0.0.1 -n 6 1>nul 2>nul
)
call :ohook 1>nul 2>nul

echo Finished.
goto :end

:get_reg
for /f "skip=%_sk% tokens=1,2*" %%i in ('"reg.exe query %1 /v Path" 2^>nul') do if /i "%%i"=="Path" if not "%%~k"=="" if exist "%%~k\OSPP*" (
set "%2=%%~k"
)
goto :eof

:ohook
set "_lnk=fsutil hardlink create"
mklink 2>nul
if %errorlevel% neq 9009 set "_lnk=mklink"
del /f /q "%osp_path%\SPPCS.DLL"
ren "%osp_path%\OSPPC.DLL" SPPCS.DLL || (set "msg=rename original osppc"&goto :abort)
copy /y "%~dp0sppc%arch%.dll" "%osp_path%\OSPPC.DLL" || (set "msg=copy ohook sppc"&goto :abort)
if defined osp_wow (
del /f /q "%osp_wow%\SPPCS.DLL"
ren "%osp_wow%\OSPPC.DLL" SPPCS.DLL || (set "msg=rename original 32-bit osppc"&goto :abort)
copy /y "%~dp0sppc32.dll" "%osp_wow%\OSPPC.DLL" || (set "msg=copy ohook 32-bit sppc"&goto :abort)
%_lnk% "%off_wow%\SPPCS.DLL" "%osp_wow%\SPPCS.DLL" || (set "msg=link renamed 32-bit osppc"&goto :abort)
) else (
%_lnk% "%off_path%\SPPCS.DLL" "%osp_path%\SPPCS.DLL" || (set "msg=link renamed osppc"&goto :abort)
)
goto :eof

:abort
echo ==== Error =====
echo Failed to %msg% dll file.
echo Close Office programs or restart the system and try again.
copy /y "%osp_path%\SPPCS.DLL" "%osp_path%\OSPPC.DLL" 1>nul 2>nul
copy /y "%osp_wow%\SPPCS.DLL" "%osp_wow%\OSPPC.DLL" 1>nul 2>nul
goto :end

:closeOFF
if not exist "%SystemRoot%\System32\tasklist.exe" goto :eof
if not exist "%SystemRoot%\System32\taskkill.exe" goto :eof
for %%# in (
msosync
msaccess
excel
groove
lync
onenote
outlook
powerpnt
mspub
winword
winproj
visio
msouc
ois
graph
) do (
tasklist /FI "IMAGENAME eq %%#.exe" | find /i "%%#.exe" && (
  taskkill /t /f /IM %%#.exe
  set _png=1
  )
)
goto :eof

:end
echo.
echo Press any key to exit.
pause >nul
exit
